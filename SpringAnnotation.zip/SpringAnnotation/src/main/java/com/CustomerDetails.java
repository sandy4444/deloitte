package com;

public class CustomerDetails {

	private String email;
	private int contactnum;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getContactnum() {
		return contactnum;
	}
	public void setContactnum(int contactnum) {
		this.contactnum = contactnum;
	}
	@Override
	public String toString() {
		return "CustomerDetails [email=" + email + ", contactnum=" + contactnum + "]";
	}
	
	
	
}
