package assss2;

public abstract class Airthmatic {
	



	abstract int calculation(int a, int b);
	abstract void display(int result);
	



}
