package assss2;

import java.util.Scanner;

public class Calculator {

		private static final String num1 = null;

		public static void main(String[] args) {
			int number1, number2,choice;
			System.out.println("Press 1- Addition ");
			System.out.println("Press 2- Subtraction ");
			System.out.println("Press 3- Multiplication");
			System.out.println("Press 4- Division ");
			
			Scanner in=new Scanner(System.in);
			choice=in.nextInt();
			
			System.out.println("Enter the number1 and number2 respectfully to calculate : ");
			number1=in.nextInt();
			number2=in.nextInt();
			
			
			Object[] calculator= {new Addition(),new Subtraction(),new Multiplication(),new Object()};
			
			
			int result=((Airthmatic) calculator[choice-1]).calculation(number1, number2);
			
			((Airthmatic) calculator[choice-1]).display(result);

			
			

			
	}


}
