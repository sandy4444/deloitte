package assss2;

public class Subtraction extends Airthmatic {

	@Override
	int calculation(int a, int b) {
		// TODO Auto-generated method stub
		
		return a-b;
	}

	@Override
	void display(int result) {
		// TODO Auto-generated method stub
		System.out.println(result);
	}
	

}
