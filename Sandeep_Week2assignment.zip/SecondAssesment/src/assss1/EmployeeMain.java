package assss1;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class EmployeeMain {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter The Number OFEmployees:");
		int number = sc.nextInt();
		EmplyeeBo eb = new EmplyeeBo();
		EmplyeeVo[] ev = new EmplyeeVo[number];
		for (int i = 0; i < ev.length; i++) {
			System.out.println("Enter Employee : "+i+" details ");
			ev[i] = new EmplyeeVo(sc.nextInt(), sc.next(), sc.nextDouble(), 0);
		}
		sc.close();
		for (EmplyeeVo e : ev) {
			eb.calincomeTax(e);
			System.out.println(e);
		}
		
		
		// Sorting
		List<EmplyeeVo> list = Arrays.asList(ev);
		Collections.sort(list, new Emplyeesort());

		System.out.println("NEW Array ____________");
		System.out.println(list);
	}



	

}
