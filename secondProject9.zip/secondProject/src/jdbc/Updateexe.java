package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import objectclass.customer;

public class Updateexe {
	
	public static void main(String[] args) throws SQLException {
		Connection connection=DbConnection.makeConnection();
	customer c= new customer();
	c.accept();
	
	System.out.println("enter the customerid you want to info for :");
	Scanner in= new Scanner(System.in);
	int id=in.nextInt();
	
	
	
	PreparedStatement statement=connection.prepareStatement("update hr.customer set CUSTOMERNAME=?,CUSTOMERADDRESS=?,BILLAMOUNT=? where CUSTOMER =?");
	
			
			statement.setInt(4,id);
			statement.setString(1,c.getCustomerName());
			statement.setString(2,c.getCustomerAdd());
			statement.setInt(3,c.getBillAmount());
			
			
			statement.executeUpdate();
			System.out.println(c.getCustomerName()+" ,your record saved succesfully");
			connection.close();
	
		
		
		
	}

}
