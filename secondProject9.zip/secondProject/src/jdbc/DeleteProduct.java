package jdbc;

import java.sql.Connection;

public class DeleteProduct {
	public static void main(String[] args) {
	
	Connection connection= DbConnection.makeConnection();
	
	
			 
		
		
		
		
	}
	

}
