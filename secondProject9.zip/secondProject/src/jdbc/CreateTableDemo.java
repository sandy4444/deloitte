package jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateTableDemo {

	
	public static void main(String[] args) throws SQLException {
		Connection connection=DbConnection.makeConnection();
		
		Statement statement= connection.createStatement();
		
		String query="create  table hr.salary(salary Integer,Bonus Integer)";
		statement.execute(query);
		
		System.out.println("");
		statement.close();
		connection.close();
		
	}
	
}
