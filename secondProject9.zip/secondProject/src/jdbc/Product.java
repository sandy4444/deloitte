package jdbc;

import java.util.Scanner;

public class Product {
int productID;
String productName;
int  price;
int quantity;
	
public void accept() {
	
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter product id : "); productID = scanner.nextInt();
    System.out.println("Enter product name : "); productName = scanner.next();
    System.out.println("Enter pro price: "); price = scanner.nextInt();
    System.out.println("Enter pro quantity : "); quantity = scanner.nextInt();
}

public int getProductID() {
	return productID;
}

public String getProductName() {
	return productName;
}

public int getPrice() {
	return price;
}

public int getQuantity() {
	return quantity;
}
	
	
}
