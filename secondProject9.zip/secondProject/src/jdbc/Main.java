package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.driver.DBConversion;

public class Main {

	public static void main(String[] args) throws SQLException {
		
		customer c = new customer();
		c.accept();
		Connection connection=DbConnection.makeConnection();
		PreparedStatement statement=connection.prepareStatement("insert into hr.customer values(?,?,?,?)");
		
				statement.setInt(1,c.getCustomerId());
				statement.setString(2,c.getCustomerName());
				statement.setString(3,c.getCustomerAdd());
				statement.setInt(4,c.getBillAmount());
				
				
				statement.executeUpdate();
				System.out.println(c.getCustomerName()+" ,your record saved succesfully");
				connection.close();
				
	}
	}
