package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class jdbcAdv {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
	
	Connection connection=DbConnection.makeConnection();
	
	//
	Statement stat=connection.createStatement();
	ResultSet res=stat.executeQuery("select hr.customer.* from hr.customer");
	
	
	while(res.next()) {
		System.out.print(res.getInt(1)+" ");
		System.out.print(res.getString(2)+" ");
		System.out.print(res.getString(3)+" ");
		System.out.println(res.getInt(4)+" ");
		
		res.moveToInsertRow();
		res.updateInt("CUSTOMER", 3);
		res.updateString("CUSTOMERNAME","geetha");
		res.updateString("CUSTOMERaddress","agra");
	
	
	}
	stat.close();
	connection.close();
	
	
	
	
	
	}
	

}
