package jdbc;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public interface DisplayRecords {
public static void main(String[] args) throws SQLException {
	Connection connection=DbConnection.makeConnection();
	
	//Product product=new Product();
	
	Statement state=connection.createStatement();
	ResultSet res= state.executeQuery("select * from hr.product");
	while(res.next()) {
		System.out.print(res.getString(1)+" ");
		System.out.print(res.getInt(2)+" ");
		System.out.print(res.getInt(3)+" ");
		System.out.println(res.getInt(4)+" ");
	
	
	}
	 
	state.close();
	
	
}
}
