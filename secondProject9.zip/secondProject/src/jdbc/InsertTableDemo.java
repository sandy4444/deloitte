package jdbc;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import oracle.jdbc.driver.DBConversion;

public class InsertTableDemo {
 public static void main(String[] args) throws SQLException {
	Connection connection=DbConnection.makeConnection();
	
	Statement statement=connection.createStatement();
	
	String insertQ="insert into hr.customer values(1877,'bibhu','bhub',50000)";
	
	int rowsAffected = statement.executeUpdate(insertQ);
	
	System.out.println("Insert success with "+rowsAffected);
}
}
