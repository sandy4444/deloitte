package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import oracle.jdbc.driver.DBConversion;

public class InsertRecordIntoProduct {
	public static void main(String[] args) throws SQLException {
		
		
		Connection connection=DbConnection.makeConnection();
		Product product=new Product();
		product.accept();
		
		PreparedStatement statement=connection.prepareStatement("insert into hr.product values(?,?,?,?)");
		
		
		
		statement.setString(1,product.getProductName());
		statement.setInt(2,product.getProductID());
		statement.setInt(3,product.getPrice());
		statement.setInt(4,product.getQuantity());
		System.out.println("new Details inserted");
		
		
		statement.close();
		
	}
	
	
	
	
	
	
	
	

}
