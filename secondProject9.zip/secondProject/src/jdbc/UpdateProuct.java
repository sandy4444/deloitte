package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

import objectclass.customer;

public class UpdateProuct{
	
	public static void main(String[] args) throws SQLException {
		Connection connection=DbConnection.makeConnection();
	Product p= new Product();
	p.accept();
	
	System.out.println("enter the productid you want to info for :");
	Scanner in= new Scanner(System.in);
	int id=in.nextInt();
	
	
	
	PreparedStatement statement=connection.prepareStatement("update hr.product set PRODUCT=?,PRODUCTID=?,PRICE=? where CUSTOMER =?");
	
			
			statement.setInt(4,id);
			statement.setString(1,p.getProductName());
			statement.setInt(2,p.getPrice());
			statement.setInt(3,p.getQuantity());
			
			
			statement.executeUpdate();
			System.out.println(p.getProductName()+" ,your record saved succesfully");
			connection.close();
	
		
		
		
	}

}
