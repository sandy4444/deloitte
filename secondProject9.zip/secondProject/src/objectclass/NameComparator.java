package objectclass;

import java.util.Comparator;


public class NameComparator implements Comparator<customer> {

	@Override
	public int compare(customer c1, customer c2) {
		// TODO Auto-generated method stub
		
		
			if(c1.getCustomerName().compareTo(c2.getCustomerName())> 0)
			{
				return 0;
			}
			else {
				return -1;
			}
	
	}

}
