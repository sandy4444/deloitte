package objectclass;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Demo1 {
	public static void main(String[] args) {

		List names=new ArrayList();
		names.add("Himanshu");
		names.add("ajay");
		names.add("sandeep");
		names.add("sam");
		System.out.println(names);
		
		Iterator<String> i=names.iterator();
		
		while(i.hasNext()) {
			String str=i.next();
			if(str.equals("ajay"))
			{
				continue;
			}
			System.out.println(str);
		}
	}
}
