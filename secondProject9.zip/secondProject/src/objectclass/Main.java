package objectclass;

public class Main {
			
	public static void main() {
		
	}
}