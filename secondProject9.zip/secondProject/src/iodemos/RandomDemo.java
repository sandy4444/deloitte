package iodemos;

import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Random;
import java.util.Scanner;

public class RandomDemo {

	public static void main(String[] args) throws IOException {
		RandomAccessFile file= new RandomAccessFile("friday.txt","rw");
		file.writeUTF("Today is friday");
		System.out.println(file.getFilePointer());
		file.seek(0);
		System.out.println(file.getFilePointer());
		String str=file.readUTF();
		//file.close();
		System.out.println("FIle content is: ");
		System.out.println(str);
		file.seek(file.length());
		System.out.println("enter the content you want to append");
		Scanner in= new Scanner(System.in);
		str=in.next();
		file.writeUTF(str);
		file.seek(0);
		str=file.readLine();
		
		file.close();
		System.out.println("content of file after appending: ");
		System.out.println(str);
		
	}
	
}
