package designPattern;

public class Bank {
	
	public static void main(String[] args) {
		Payment payment=Payment.getPaymentObject();
		payment.pay(10000);
		
	}

}
