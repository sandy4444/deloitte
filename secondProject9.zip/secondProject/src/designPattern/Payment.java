package designPattern;

public class Payment {
	
	private static Payment payment= new Payment();
	
	
	private Payment() {
		// TODO Auto-generated constructor stub
	System.out.println("payment memory generated");	
	}
	
	public static Payment getPaymentObject() {
		return payment;
		
	}
		

	public void pay(int amount) {
		// TODO Auto-generated method stub
		
		System.out.println("payment done for INR: "+amount);
	}

}
