package oops;

public class W {
public W()
{
	System.out.println("w constuctor");
}
{
	System.out.println("Instance block w");
	
}
static {
	 System.out.println("Static block w");
	 
}
}
