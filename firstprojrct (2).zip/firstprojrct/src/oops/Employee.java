package oops;

import java.util.Scanner;

public class Employee {

public int employeeId;
public String employeeName;
public String employeeAddress;
public int salary;

public void takeSalary()
{
	Scanner x=new Scanner(System.in);
	employeeId= x.nextInt();
	employeeName=x.next();
	employeeAddress=x.next();
	salary=x.nextInt();
		
}

public void displayDetails()
{
	System.out.println("Employee id:"+employeeId);
	System.out.println("Employee name:"+employeeName);
	System.out.println("Employee Address:"+employeeAddress);
	System.out.println("Employee salary:"+salary);
}
}
