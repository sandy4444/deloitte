package oops;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee emp= new Employee();
		emp.takeSalary();
		emp.displayDetails();
	}

}
