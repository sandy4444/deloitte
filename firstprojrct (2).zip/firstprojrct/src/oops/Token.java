package oops;

import java.util.StringTokenizer;

public class Token {
	public static void main(String[] args)
	{
		String text="THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
		StringTokenizer tokenizer= new StringTokenizer(text);
		System.out.println(tokenizer.countTokens());
		while(tokenizer.hasMoreElements()) {
			System.out.println(tokenizer.nextElement());
		}
		
	}

}
