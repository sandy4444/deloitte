package oops;

public class Z {
	W w= new W();
	{
		System.out.println("Instance block z");
		
	}
	 static {
		 System.out.println("Static block");
		 
	 }
	 
	 public Z()
	 {
		 System.out.println("Z constructor");
	 }
	  public  static void main(String[] args)
	  {
		  System.out.println( " in main");
		  new Z();
		  System.out.println( "-----------");
		  new Z();
	  }

}
