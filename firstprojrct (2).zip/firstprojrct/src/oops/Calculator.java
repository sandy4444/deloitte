package oops;

public class Calculator {
	
	public void  add(int a,int b) {
		int c=a+b;
		System.out.println(c);
	}
	public void  add(double a,double b) {
		double c=a+b;
		System.out.println(c);
	}
	public void  add(int a,double b) {
		double c=(double)a+b;
		System.out.println(c);
	}
	public void  add(double a,int b) {
		double c=a+(double)b;
		System.out.println(c);
	}
	public void sub(int a,int b) {
	
		int c=a-b;
  System.out.println(c);
	}
	public void sub(double a,double b) {
		
		double c=(double)a-b;
  System.out.println(c);
	}

	public void sub(double a,int b) {
		
		double c=a-(double)b;
  System.out.println(c);
	}

	public void sub(int a,double b) {
		
		double c=(double)a-b;
  System.out.println(c);
	}
	public void  mul(int a,int b) {
		int c=a*b;
		System.out.println(c);
	}
	public void  mul(double a,double b) {
		double c=a*b;
		System.out.println(c);
	}
	public void  mul(int a,double b) {
		double c=(double)a*b;
		System.out.println(c);
	}
	public void  mul(double a,int b) {
		double c=a*(double)b;
		System.out.println(c);
	}


	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculator ob= new Calculator();
		ob.add(12,12);
		ob.add(12.12,12.12);
		ob.add(12,12.12);
		ob.add(12.12,12);
		
		ob.mul(12,12);
		ob.mul(12.12,12.12);
		ob.mul(12,12.12);
		ob.mul(12.12,12);
		
		ob.sub(12,12);
		ob.sub(12.12,12.12);
		ob.sub(12,12.12);
		ob.sub(12.12,12);
		
	}

}
