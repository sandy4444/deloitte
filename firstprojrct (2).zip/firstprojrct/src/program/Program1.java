package program;
import java.util.*;
public class Program1 {

	
	void display(int a,int b) {
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("After swaping");
		System.out.println("1st int:"+a);
		System.out.println("2nd inr:"+b);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		int i,j;
		Scanner in = new Scanner(System.in);
		i=in.nextInt();
		System.out.println("1st int:"+i);
		j=in.nextInt();
		System.out.println("2nd int:"+j);
		in.close();
		 Program1 d= new Program1();
		 d.display(i, j);
		

	}

}
