package day2;

public class program2 {
	
	String s="The quick brown fox jumps over the lazy dog";
	
public void getcharposition()
{
	char[] ch= s.toCharArray();
	System.out.println(ch[11]);
	
}
	
 public void searchChar() {
	 int count=0;
	 char[] ch= s.toCharArray();
	 for(int i=0;i<ch.length;i++) {
		 if(ch[i]=='s')
		 {
			 count++;
			 break;
		 }
		 if(count>0)
		 {
			 System.out.println("word contains s");
		 }
		 else System.out.println("word does not contain s");
			 
	 }
 }
 
	 
	 public void addString() {
		 String s2="and killed it";
		 String s3=s+s2;
		 System.out.println(s3);
		 		 
	 }
	 
	 public void checkWord() {
		 
	 }
	 
	 public void checkSameOrNotLower() {
		 String s4="The quick brown Fox jumps over the lazy Dog";
		 System.out.println(s==s4);
		 
	 }
	 
	 public void checkSameOrNotUpper() {
		 String s4="THE QUICK BROWN FOX JUMPS OVER THE LAZY DOG";
		 System.out.println(s==s4);
 }
	 public  void getLength() {
		 System.out.println(s.length());
	 }
	 
	 public void  positionOfA() {
		 char[] ch= s.toCharArray();
		 for(int i=0;i<ch.length;i++)
		 {
			 if(ch[i]=='a')
			 {
				 
			 }
		 }
		 
		 
	 }
	 
	 

}
