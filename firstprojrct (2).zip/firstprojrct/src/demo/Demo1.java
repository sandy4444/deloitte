package demo;

public class Demo1 {

	int i;
	int num=10;
	public void display()
	{
		int j=10;
		if(num==20)
		{
			j=20;
		}
		System.out.println((i+num)-j);
		
	}
	public static void main(String[] args) {
		Demo1 d=new 
();
		d.display();
	}
}
