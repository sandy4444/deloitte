package cconst;

public class Client {

	public static void main(String[] args)
	{
		Customer c= new Customer();
		c.setBillAmont(100);
		c.getBillAmont();
		
	}
	
}
