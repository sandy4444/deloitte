package cconst;

public class Customer {
	private int customerId;
	private String customerName;
	private String customerAddress;
	private int billAmont=1000;
	
	
	public Customer() {
		customerId=1001;
		customerName="mohan";
		customerAddress="delhi";
		 billAmont=1001;
	}
	public Customer(int customerId,String customerName,String customerAddress,int billAmont)
	{
		this.customerAddress=customerAddress;
		this.customerId=customerId;
		this.billAmont=billAmont;
		this.customerName=customerAddress;
	}
	
	public void  display()
	{
		System.out.println(customerAddress);
		System.out.println(customerId);
		System.out.println(customerName);
		System.out.println(billAmont);
	}

	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public int getBillAmont() {
		return billAmont;
	}
	public void setBillAmont(int billAmont) {
		this.billAmont = billAmont;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c= new Customer();
		c.display();
		Customer d= new Customer(100,"ram","goa", 1003);
		d.display();

	}

}
