package com.cms.deloitte.Client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;

public class LaunchCustomerApplication {
	public static void startCustomerApp() {
		CustomerDAO customerDAO= new CustomerDAOImpl();
		
		System.out.println("#### Welcome to Customer App ###");
		System.out.println("#### 1.Add Customer ###");
		System.out.println("#### 2.Update Customer ####");
		System.out.println("#### 3.to delete Record ###");
		System.out.println("#### 4 List of all Customer. ###");
		System.out.println("#### 5. to find the customerEXIT ###");
		System.out.println("#### 6.EXIT ###");
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your choice");
		int choice=sc.nextInt();
		if(choice==1) {
			
			Customer customer=new Customer();
			customer.acceptCustomerDetails();
			boolean result=false;
			if(customerDAO.isCustomerExsits(customer.getCustomerId())) {
				System.out.println(customer.getCustomerId()+" already exist");
			}
			else {
				CustomerDAOImpl impl=new CustomerDAOImpl();
			 result=customerDAO.addCustomer(customer);
				System.out.println(customer.getCustomerName()+" added successfully");
			}
			
		}
		else if(choice==2) {
			System.out.println("Please enter the NEw Details: ");
			Customer customer= new Customer();
			if(customerDAO.isCustomerExsits(customer.getCustomerId())) {
				customerDAO.updateCustomer(customer);
				System.out.println(customer.getCustomerName()+" updated successfully");
				
			}
			
		}else if(choice==3) {
			System.out.println("pleae enter the customerid: ");
			
			int customerID=sc.nextInt();
			if(customerDAO.isCustomerExsits(customerID)) {
				customerDAO.deleteCustomer(customerID);
				System.out.println(customerID+" deleted successfully ");
			}
			else {
				System.out.println(customerID+" does not exist");
			}
			
			
		}else if(choice==4) {
			
			List<Customer> allCustomers = new ArrayList<Customer>();
			allCustomers=customerDAO.listCustomer();
			System.out.println("List of all Customers");
			System.out.println(allCustomers);
			
		}else if(choice==5) {
			Customer customer = new Customer();
			System.out.println("Enter the ID to be found");
			int id = sc.nextInt();
			if (customerDAO.isCustomerExsits(id)) {
				customer = customerDAO.findCustomer(id);
				System.out.println(customer);
			} else
				System.out.println("Customer with id = " + id + " does not exist");
			
			
			
		}else if(choice==6) {
			System.out.println("Thank you for using the app");
			System.exit(0);
		}else {
			System.out.println("Invalid Option, Please enter the right option");
		}
		sc.close();
	}
}
