package execeptiondemo;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Demo {
	
	int num1,num2;
	int result;
	Scanner  in= new Scanner(System.in);
	  void display() {
		// TODO Auto-generated method stub
		   System.out.println("Welcome to display");
		   try {
			   System.out.println("please enter the 1st num:");
			   num1= in.nextInt();
			   System.out.println("please enter the 2nd num:");
			   num2= in.nextInt();
			   result=num1/num2;
			   System.out.println("result: "+result);
			 
		   }
		   
		   catch (InputMismatchException e) {
			   System.out.println("you have enter other than number");
			   
			// TODO: handle exception
		}
		   catch (ArithmeticException e) {
			   System.out.println("you have enter 0 which is not possible");
			   
			// TODO: handle exception
		}
	}
	  
	  
	  public static void main(String[] args) {
		System.out.println("WElcome to main");
		Demo d= new Demo();
		
		d.display();
		System.out.println("Thank you");
		
	
	
	}

}
