package execeptiondemo;

import java.util.Scanner;


class InvalidAgeException extends Exception{
  public InvalidAgeException() {
		// TODO Auto-generated constructor stub
	}
	public InvalidAgeException(String msg) {
		super(msg);
	}
	
}



public class DEmo3 {
	public static void main(String[] args) throws InvalidAgeException {
		NewYearParty d= new  NewYearParty();
		d.enterClub();
		
	}
}

class NewYearParty
{
	int eligibleAge=16;
	Scanner in= new Scanner(System.in);
			int age;
	public void enterClub() throws InvalidAgeException {
		System.out.println("Please enter your age :");
		age=in.nextInt();
		if(age<eligibleAge)
		{
			throw  new InvalidAgeException("You are under age");
		}
		else {
			System.out.println("Welcome to the party");
		}
		System.out.println("Enjoy");
	}
}
