package iodemos;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class ReadFileDemo2 {
	public static void main(String[] args) throws IOException {
		File file= new File("mohan.txt.txt");
		FileWriter reader = new FileWriter(file);
		/*int i=0;
		while((i=reader.read())!=-1) {
			System.out.print((char)i);
		}*/
		
		reader.write("my name is sam");
		System.out.println("Done ");
		reader.close();
	}
	

}

