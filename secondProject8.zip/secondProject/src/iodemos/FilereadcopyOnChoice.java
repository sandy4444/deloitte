package iodemos;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FilereadcopyOnChoice {
	
	public static void main(String[] args) throws IOException {
		Scanner in= new Scanner(System.in);
		
		
		System.out.println("Enter the file to copy:");
		String s= in.nextLine();
		
		
		File  file=new File(s);
		if(file.exists()) {
			System.out.println("Enter the file to paste info");
			String t= in.nextLine();
			FileReader reader= new FileReader(s);
			FileWriter  writer=new FileWriter(t);
			
			
			int i=0;
			
			while((i=reader.read())!=-1)
			{
				writer.append( (char)i);
			}
			
			writer.close();
			reader.close();
			System.out.println("read and copy done");
			
			
		
		}
		else {	
			
			
			System.out.println(s+" Does not exsits");
		}
	}
	

}
