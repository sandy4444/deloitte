package iodemos;

import java.io.File;
import java.io.IOException;

public class Demoexer {
	
	public static void main(String[] args) throws IOException {
		
		File file=new File("E:\\\\Deloitte\\\\Batch\\\\BatchMates.txt");
		File sec= new File("E:\\\\Deloitte\\\\Batch");
		 if(file.exists()) {
			 System.out.println("File is  already here...");
			 file.delete();
		 }
		 else {
			 
			 file.createNewFile();
			 System.out.println("New File created...");
		 }
		 
		 
		 
		System.out.println("Done");

		
		
	}

}
