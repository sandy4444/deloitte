package iodemos;

import java.io.File;
import java.io.IOException;

public class Demo1 {
	public static void main(String[] args) throws IOException {
		
		File file= new File("E:\\Deloitte\\demo\\newyear.txt");
		 File h= new File("E:\\\\Deloitte\\\\demo");
		 if(file.exists()) {
			 System.out.println("File is here...");
			 file.delete();
		 }
		 else {
			 h.mkdirs();
			 file.createNewFile();
			 System.out.println("New File created...");
		 }
		System.out.println("Done");

	
	}

}
