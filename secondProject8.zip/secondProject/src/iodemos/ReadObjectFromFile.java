package iodemos;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.nio.channels.FileLockInterruptionException;

import objectclass.customer;

public class ReadObjectFromFile {
	
	public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
		customer c=new customer();
		ObjectInputStream  stream= new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("delu.txt"))));
	
	c=(customer)stream.readObject();
	System.out.println(c);
	
	}
	

}
