package iodemos;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReadAndCopy {
	
	public static void main(String[] args) throws IOException {
		
		
		
		
		
		FileReader reader= new FileReader("mohan.txt.txt");
		FileWriter  writer=new FileWriter("WriterFile.txt");
		
		
		int i=0;
		
		while((i=reader.read())!=-1)
		{
			writer.append( (char)i);
		}
		
		writer.close();
		reader.close();
		System.out.println("read and copy done");
		
	}
	

}
