package objectclass;

import java.io.Serializable;
import java.util.Scanner;

public class customer implements Serializable, Comparable<customer> {
private int CustomerId;
private String CustomerName;
private String CustomerAdd;
private int billAmount;

public void accept() {
	
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter customer id : "); CustomerId = scanner.nextInt();
    System.out.println("Enter customer name : "); CustomerName = scanner.next();
    System.out.println("Enter customer address : "); CustomerAdd = scanner.next();
    System.out.println("Enter bill amount : "); billAmount = scanner.nextInt();
}


public customer(int customerId, String customerName, String customerAdd, int billAmount) {
	super();
	this.CustomerId = customerId;
	this.CustomerName = customerName;
	this.CustomerAdd = customerAdd;
	this.billAmount = billAmount;
}
public customer() {
	// TODO Auto-generated constructor stub
}


public int getCustomerId() {
	return CustomerId;
}
public void setCustomerId(int customerId) {
	CustomerId = customerId;
}
public String getCustomerName() {
	return CustomerName;
}
public void setCustomerName(String customerName) {
	CustomerName = customerName;
}
public String getCustomerAdd() {
	return CustomerAdd;
}
public void setCustomerAdd(String customerAdd) {
	CustomerAdd = customerAdd;
}
public int getBillAmount() {
	return billAmount;
}
public void setBillAmount(int billAmount) {
	this.billAmount = billAmount;
}

@Override
public String toString() {
	return "\n[CustomerId : "+CustomerId+",CustomerName : "+CustomerName+",CustomerAdd : "+CustomerAdd+",Bill Amount : "+billAmount+"]";
}
	/*public static void main(String[] args) {
		customer customer = new customer(007,"James Bond","UK",97000);
		System.out.println(customer);
		customer.setBillAmount(50000);
		System.out.println(customer);
	}*/
@Override
public int compareTo(customer o) {
	// TODO Auto-generated method stub
	if(this.getBillAmount( )> o.billAmount)
	return -1;
	else
		return 0;
}

}
