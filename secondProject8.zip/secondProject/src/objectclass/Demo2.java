package objectclass;

import java.util.LinkedHashSet;
import java.util.Set;

public class Demo2 {
	
	
	public static void main(String[] args) {
		Set names= new LinkedHashSet();
		
		names.add ("sandeep");
		names.add("abhishek");
		names.add("sourav");
		names.add(100);
		System.out.println(names);
		
	}

}
