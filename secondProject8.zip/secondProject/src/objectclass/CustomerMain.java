package objectclass;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class CustomerMain {
	
public static void main(String[] args) {
	List<customer> allCustomer=new ArrayList<customer>();
	
	customer customer1= new customer(101, "Pooja","Delhi", 25000);
	allCustomer.add(customer1);
	allCustomer.add(new customer(103, "Tarun", "agara", 45000));
	allCustomer.add(new customer(103,"Harish" , "Mumbai", 78000));
	
	System.out.println(allCustomer);


Iterator<customer> customerIterator = allCustomer.iterator();
while(customerIterator.hasNext()) {
	customer cust=customerIterator.next();
	System.out.println(cust);
}

/*System.out.println("after sorting");

Collections.sort(allCustomer);
Iterator<customer> customerIterator1 = allCustomer.iterator();
while(customerIterator1.hasNext()) {
	customer cust=customerIterator1.next();
	System.out.println(cust);
*/
	
	
	
	System.out.println("sort on 1.NAmes 2.Address 3.Bill Amount ??");
	Scanner c= new Scanner(System.in);

	int choice = c.nextInt();
		
	
	//sorting choice
	if(choice == 1) {
		System.out.println("Sorting based on Bill");
		Collections.sort(allCustomer);
		System.out.println(allCustomer);
		}
		
		else if(choice == 2) {
		System.out.println("Sorting based on Name");
		Collections.sort(allCustomer,new NameComparator());
		System.out.println(allCustomer);
		}
		
		else {
		System.out.println("Sorting based on Address");
		Collections.sort(allCustomer);
		System.out.println(allCustomer);
		}
		
		//System.out.println(allCustomers);
	
}
}



