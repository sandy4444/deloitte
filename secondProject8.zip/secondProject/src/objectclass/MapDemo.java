package objectclass;

import java.util.HashMap;
import java.util.Map;

public class MapDemo {
	public static void main(String[] args) {
		
		Map<Integer,String> allData= new HashMap<Integer,String>();
		allData.put(101, "sandeep");
		allData.put(103, "Delhi");
		allData.put(105, "sam");
		
	}

}
