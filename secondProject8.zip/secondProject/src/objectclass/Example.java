package objectclass;

public class Example {
	
	 private int productId;
	 private String productName;
	 private int quantity;
	 private int price;
	 
	 
	

}
