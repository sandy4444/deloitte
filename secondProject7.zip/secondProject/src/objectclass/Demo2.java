package objectclass;

import java.util.LinkedHashSet;
import java.util.Set;

public class Demo2 {
	
	
	public static void main(String[] args) {
		Set names= new LinkedHashSet();
		
		names.add ("sandeep");
		names.add("abhishek");
		names.add("sourav");
		System.out.println(names);
		
	}

}
