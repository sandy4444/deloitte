package objectclass;

import java.util.ArrayList;
import java.util.List;

public class Demo1 {
	public static void main(String[] args) {

		List names=new ArrayList();
		names.add("Himanshu");
		names.add("ajay");
		names.add("sandeep");
		names.add("sam");
		System.out.println(names);
		
	}
}
