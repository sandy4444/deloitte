package execeptiondemo;

import java.util.Scanner;

public class Demo2 {
	
	int num1,num2;
	int result;
	Scanner  in= new Scanner(System.in);
	  public  void display1() {
		
		   System.out.println("Welcome to display");
		   Thread.sleep(10000);
	  }
	  
		 public void display2(){
			  	System.out.println("Wlecome to display2");
			  	Thread.sleep(10000);
		}   
	
}
	  
	  
	  public static void main(String[] args) {
		System.out.println("WElcome to main");
		Demo2 d= new Demo2();
		
		d.display1();
		d.display2();
		System.out.println("Thank you");
		
	
	
	}

}
