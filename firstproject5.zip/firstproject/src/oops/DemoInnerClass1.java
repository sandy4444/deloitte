package oops;


interface ChangePassword1{
	
	
	void doChange();
	
}
public class DemoInnerClass1 {
	public static void main(String[] args) {
		ChangePassword1 c= new ChangePassword1() {
			
			@Override
			public void doChange() {
				// TODO Auto-generated method stub
				System.out.println("password Change successfully");
				
			}
		};
		c.doChange();
	}

}
