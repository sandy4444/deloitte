package oops;

public class Abst {
	public static void main(String[ ] args) {
		 
		 Mammals a= new Lion();
		 a.eat();
		 
		 a.makeNoise();
		 
}
}

