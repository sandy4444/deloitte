package oops;

public class Inherit {
	 
	 public static void main(String[ ] args) {
		 
		 Animal a= new Dog();
		 a.eat();
		 a= new Cat();
		 a=eat();
	 }
}
