package oops;

public class Changepassword {

	String password="pass@123";
	class EncryptPassowrd{
		
		int passwordLEvel= 5;
		public void doEncrypt() {
			System.out.println("The password :"+password);
			
		}
	}
}
