package com.deloitte.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cms.deloitte.dao.CustomerDAO;
import com.cms.deloitte.dao.impl.CustomerDAOImpl;
import com.cms.deloitte.model.Customer;
import com.cms.deloitte.service.CustomerService;

@Controller
public class CustomerController {

	@Autowired
	CustomerService customerService;
	
	
	@RequestMapping("CustomerSave")
	public ModelAndView saveCustomerDetails(Customer customer) {
		System.out.println("customer");
		customerService.addCustomer(customer);
		ModelAndView view = new ModelAndView();
		view.setViewName("result");
		view.addObject("custo",customer); 
		return view;
		
	}
	
	@RequestMapping("updateCustomer")
	public ModelAndView updateCustomerDetails(Customer customer) {
		System.out.println(customer);
		ModelAndView view= new ModelAndView();
		view.addObject("cust",customer);
		if(customerService.isCustomerExsits(customer.getCustomerId()))
		{
			customerService.updateCustomer(customer);
			view.setViewName("result");
		}
		else {
			view.setViewName("error");
		}
		
		return view;
		
	}
	
	@RequestMapping("CustomerDetails")
	public ModelAndView CustomerDetails(HttpSession session) {
		
		
		ModelAndView view = new ModelAndView();
		view.setViewName("allCustomerRecords");
		
		
		List<Customer> allCustomer=customerService.listCustomer();
		
		//view.addObject("allcusto",allCustomer);
		session.setAttribute("allCust",allCustomer);
		return view;
		
	}
	
	@RequestMapping("CustomerForm")
	public ModelAndView CustomerForm() {
		System.out.println("customer");
		
		ModelAndView view = new ModelAndView();
		view.addObject("command",new Customer());
		view.setViewName("CustomerForm");
		 
		return view;
		
	}
	
	@RequestMapping("fetchCustomer")
	public ModelAndView fetchCustomer(Customer customer ) {
		System.out.println("customer");
		Customer retrievCustomer=customerService.findCustomer(customer.getCustomerId());
		ModelAndView view = new ModelAndView();
		view.addObject("command",retrievCustomer);
		view.setViewName("CustomerForm");
		 
		return view;
		
	}
}
