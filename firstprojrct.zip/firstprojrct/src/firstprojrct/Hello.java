package firstprojrct;

public class Hello {
void  sayHello()
{
	System.out.println("welcome to Hello");
	}

}
