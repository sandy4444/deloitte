package firstprojrct;

public class Bye {
 
public void sayThank() {
	// TODO Auto-generated method stub
	 System.out.println("welcome to bye");
}
}
