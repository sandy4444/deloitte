package firstprojrct;

public class Welcome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("welcome to deloitte");
		Bye b= new Bye();
		b.sayThank();
		Hello h=new Hello();
	    h.sayHello();
	    Sandeep s= new Sandeep();
	    s.saySandeep();

	}

}
