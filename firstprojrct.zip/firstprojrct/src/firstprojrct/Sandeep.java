package firstprojrct;

public class Sandeep {
 void saySandeep()
 {
	 System.out.println("hi sandeep");
 }
}
