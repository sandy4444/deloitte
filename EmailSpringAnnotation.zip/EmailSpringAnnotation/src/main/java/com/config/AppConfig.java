package com.config;

import javax.security.auth.Subject;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.Body;
import com.Email;
import com.From;
import com.Subjectmail;
import com.To;

@Configuration
public class AppConfig {
	
	
@Bean
public Email getEmail() {
	
	return new Email();
}
	
@Bean
public To getTo() {
	
	return new To();
}
@Bean
public From getFrom() {
	return new From();
}

@Bean
public Subjectmail getSubmail () {
	return new Subjectmail();
			 
	
}
@Bean
public Body getbody () {
	return new Body();
			 
	
}

}
