package com;

import java.io.Serializable;
import java.util.Scanner;

import javax.security.auth.Subject;

import org.springframework.beans.factory.annotation.Autowired;

public class Email implements Serializable {
	@Autowired
	private To to;
	@Autowired
	private From  from;
	@Autowired(required=false)
	private Subjectmail subject;
	@Autowired(required=false)
	private Body body;

	
	public Email(To to, From from, Subjectmail subject, Body body) {
		super();
		this.to = to;
		this.from = from;
		this.subject = subject;
		this.body = body;
	}
	public Email() {
		// TODO Auto-generated constructor stub
	}
	
	public To getTo() {
		return to;
	}
	public void setTo(To to) {
		this.to = to;
	}
	public From getFrom() {
		return from;
	}
	public void setFrom(From from) {
		this.from = from;
	}
	public Subjectmail getSubject() {
		return subject;
	}
	public void setSubject(Subjectmail subject) {
		this.subject = subject;
	}
	public Body getBody() {
		return body;
	}
	public void setBody(Body body) {
		this.body = body;
	}
	@Override
	public String toString() {
		return "Email [to=" + to + ", from=" + from + ", subject=" + subject + ", body=" + body + "]";
	}
	
	
		
	
	
	
	}
	


