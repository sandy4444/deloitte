package com;

public class Subjectmail {
	
	String caption;

	@Override
	public String toString() {
		return "Subjectmail [caption=" + caption + "]";
	}

	public String getCaption() {
		return caption;
	}

	public void setCaption(String caption) {
		this.caption = caption;
	}

	public Subjectmail(String caption) {
		super();
		this.caption = caption;
	}

	public Subjectmail() {
		// TODO Auto-generated constructor stub
	}
	
	

}
