package com;

public class To {
	
	
	private String toName;
	private String ToEmail;
	public To(String toName, String toEmail) {
		super();
		this.toName = toName;
		ToEmail = toEmail;
	}
	public To() {
		// TODO Auto-generated constructor stub
	}
	public String getToName() {
		return toName;
	}
	public void setToName(String toName) {
		this.toName = toName;
	}
	public String getToEmail() {
		return ToEmail;
	}
	public void setToEmail(String toEmail) {
		ToEmail = toEmail;
	}
	@Override
	public String toString() {
		return "To [toName=" + toName + ", ToEmail=" + ToEmail + "]";
	}
	
	

}
