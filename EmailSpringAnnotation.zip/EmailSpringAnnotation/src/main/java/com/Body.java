package com;

public class Body {
	
	private String msg;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public Body(String msg) {
		super();
		this.msg = msg;
	}

	public Body() {
		// TODO Auto-generated constructor stub
	}
	

}
