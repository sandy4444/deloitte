package com.shoppingapp.deloitte.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AuthenticateServlet
 */
public class AuthenticateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuthenticateServlet() {
       
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String userName=request.getParameter("username");
		//String password=request.getParameter("password");
		PrintWriter out=response.getWriter();
		out.println("Authentication Successful!");
		
	Cookie allcookie[]=request.getCookies();
		
		
		boolean alreadyVisited= false;
		if(allcookie!=null) {
			for(Cookie c: allcookie) {
				if(c.getName().equals(userName)) {
					alreadyVisited=true;
					break;
				
				}
			}
		
		}
		out.println("<h1>Successfully authenticated");
		if(!alreadyVisited) {
			out.println("<h1>Welcome, you are visiting first time");
			Cookie cookie = new Cookie(userName, userName);
			response.addCookie(cookie);
			System.out.println("Cookie Set");
		}
		else
			out.println("<h1>Welcome Anyway");
		
	
	
	/*out.println("<h1><form action='WelcomeServlet");
	out.println("<h1>Wife name: <input type='text' name='wifeName'>");
	out.println("<h1><input type='hidden'name ='userName'value="+userName);
	out.print("<h1><input type='submit' value='Enter'>");
	out.println*/
	}
		/*if(userName.equals("Admin")) {
			
			RequestDispatcher dispatcher=request.getRequestDispatcher("AdminServlet");
			dispatcher.include(request, response);	
		}
		else if(userName.equals("Guest")){
			RequestDispatcher dispatcher=request.getRequestDispatcher("GuestName");
			dispatcher.include(request, response);	
		}else {
			RequestDispatcher dispatcher=request.getRequestDispatcher("OtherServlet");
			dispatcher.include(request, response);	
	}*/

}

