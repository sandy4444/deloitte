package oops;

public abstract class Animal
{
 public abstract void  eat();

 public void sleep() {
	 System.out.println("animal sleeps");
 }
 
 }


 class Dog extends Animal
 {
	 @Override
	 
	 public void eat()
	 {
		 System.out.println("Dogs eats meat");
	 }
	 
	 
 }
 
 class Cat extends Animal
 {
	 @Override
	 public void eat()
	 {
		 System.out.println("Cats Eats MILK");
	 }
 }
 

