package oops;

import oops.Changepassword.EncryptPassowrd;

public class DemoinnerClass{
	 public static void main(String[] args) {
		 
		 ChangePassword pa=new ChangePassword();
		 EncryptPassowrd e= pa.new EncryptPassowrd();
		 e.doEncrypt();
		 
	 }
 }