package oops;

abstract class Mammals {
	
	
	
	 abstract  void eat();
	 abstract  void roam();
   void sleep() {
		System.out.println("Its sleep");
	}
	public abstract  void makeNoise();
	

}

abstract class Canine extends Mammals{

	@Override
	public void roam() {
		// TODO Auto-generated method stub
		System.out.println("Canine roams on ...");
		
	}
	
	
 }
			
	class Lion extends Canine{
		
		@Override
		public void eat() {
			// TODO Auto-generated method stub
			System.out.println("Canine eats protein");
		}
			
			@Override
			public void makeNoise() {
				// TODO Auto-generated method stub
				System.out.println("Noise");
				
			}
		
	
	 
 }
	
	class Tiger extends Canine{

		@Override
		void eat() {
			// TODO Auto-generated method stub
			System.out.println("lIon hunts");
			
		}

		@Override
		public void makeNoise() {
			// TODO Auto-generated method stub
			System.out.println("lion Roars");
			
		}
		
		
	}
