document.write("<h1>Hello javaScript")

 function display(){
var num1= prompt("Enter first number:","12");
var num2= prompt("Enter second number:","20");
var result=parseInt(num1)+parseInt(num2);
alert("The sum of two numbers are:"+result)

 }
	
	function demo(){
		var res= confirm("Do you want to continue :");
		if(res==true)
			alert("ok clicked")
		else{
			alert("Cancel Clicked")
		}
		
	}
	
	function displaygreeting(msg){
		if(msg==null)
			{
			msg="Good Night";
			}
		alert(msg);
	}
	